//
//  TrackLocationViewController.swift
//  NuevacareClient
//
//  Created by Bhavik  on 13/10/16.
//  Copyright © 2016 Credencys. All rights reserved.
//

import UIKit
import GoogleMaps
import CoreLocation

//Google Map Key Provide
//GMSServices.provideAPIKey("AIzaSyC7k52QhjLQ-KPv-tzLSkt7SKxZdb0Hqj4")

class TrackLocationViewController: UIViewController,CLLocationManagerDelegate{

    @IBOutlet weak var btnBack           :   UIButton!
    @IBOutlet weak var lblTitle          :   UILabel!
    @IBOutlet weak var lblName           :   UILabel!
    @IBOutlet weak var lblTime           :   UILabel!
    @IBOutlet weak var lblKm             :   UILabel!
    @IBOutlet weak var btnDirection      :   UIButton!
    
    var doubleLat:Double = 0.0
    var doubleLong:Double = 0.0
    
    var caregiverLatitude:Double = 0.0
    var caregiverLongitude:Double = 0.0
    
    var strCurDate : String = ""
    var strCurTime : String = ""
    
    var marker = GMSMarker()
    var markerCareGiver = GMSMarker()
    
    @IBOutlet weak var mapView:GMSMapView!
    
    var currentTag:Int = 0
    var timer:Timer?
    
     var caregiver_id : NSInteger!
    
    //Dictionary
    var careGiverDict = NSDictionary()
    
    //Array
    var markers = NSMutableArray()    
    
    //Alpesh

    var dictdirection : NSDictionary = [:]
    @IBOutlet weak var lbladdress: UILabel!
    @IBOutlet weak var lblZipe: UILabel!
    
    
    //Cur Location
    var locationManager: CLLocationManager!
    var location : CLLocation = CLLocation()
    var lastLocation : CLLocationCoordinate2D = CLLocationCoordinate2D()
    
   override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK:View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(dictdirection)
    
        self.setUPUI()
        self.setUPFont()
        self.setUPCareGiverData()
        self.setupMapView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        caregiverLongitude = 0.0
        caregiverLatitude = 0.0
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
    }

    
    //MARK:SetUp UI
    func setUPUI()
    {
        DispatchQueue.main.async {
            self.lblKm.layer.cornerRadius = 12.0
            self.lblKm.layer.masksToBounds = true
        }
    }
    
    //MARK:Check Display Caregiver Location
    
    func CaregiverLocationDisplay()
    {
    
        let clientLocation = CLLocation(latitude: doubleLat, longitude: doubleLong)
        let caregiverLocation = CLLocation(latitude: SharedInstance.curLatitude, longitude: SharedInstance.curLongitude)
        
        print(clientLocation)
        print(caregiverLocation)
        
        if(SharedInstance.isLocationEnable)
        {
            let distance = self.distanceBetweenTwoLocations(source: caregiverLocation, destination: clientLocation)
            
            print("Distance:",distance)
            
            lblKm.text = String(format:"%.01f kms", distance)
            lblKm.isHidden = false
            btnDirection.isHidden = false
        }
        else
        {
            lblKm.isHidden = true
            btnDirection.isHidden = true
        }
        
        marker.position = CLLocationCoordinate2DMake(doubleLat, doubleLong)
        
        markerCareGiver.position = CLLocationCoordinate2DMake(SharedInstance.curLatitude, SharedInstance.curLongitude)
        
        markerCareGiver.title = ""
        markerCareGiver.snippet = ""
        markerCareGiver.isDraggable = true
        markerCareGiver.icon = UIImage(named: "CaregiverMarker")
        markerCareGiver.map = mapView
        
        
        print(SharedInstance.curLatitude)
        print(caregiverLatitude)
        
        if(SharedInstance.curLatitude != caregiverLatitude || SharedInstance.curLongitude != caregiverLongitude)
        {
            
            caregiverLatitude = SharedInstance.curLatitude
            caregiverLongitude = SharedInstance.curLongitude
            
            markers.removeAllObjects()
            
            markers.add(marker)
            markers.add(markerCareGiver)
            
            let firstLocation = (markers.firstObject as! GMSMarker).position
            
            var bounds = GMSCoordinateBounds().includingCoordinate(firstLocation)
            
            for marker in markers {
                bounds = bounds.includingCoordinate((marker as AnyObject).position)
            }
            mapView.animate(with: GMSCameraUpdate.fit(bounds, withPadding: 50.0))
        }

    }
    
    //MARK:SetCaregiverData
    
    func  setUPCareGiverData()
    {
       
        lblName.text = dictdirection.value(forKey: "name") as? String
        
        lbladdress.text =  String(format:"%@",(dictdirection.value(forKey: "address") as? String)!)
        
        let lastChar =  lbladdress.text?.characters.last!
        
        if lastChar == "\n" {
            
            let truncated = lbladdress.text?.substring(to: (lbladdress.text?.index(before: (lbladdress.text?.endIndex)!))!)
            
            lbladdress.text = truncated
        }
        
        lblZipe.text =  String(format:"%@,%@-%@", (dictdirection.value(forKey: "city") as? String)!,(dictdirection.value(forKey: "state") as? String)!,(dictdirection.value(forKey: "pincode") as? String)!)
        
        let timeFormatter = DateFormatter()
        timeFormatter.dateFormat = "HH:mm:ss"
        
        
        let shift_start_time = timeFormatter.date(from: (dictdirection.value(forKey: "start_time") as? String)!)
        
        let shift_end_time = timeFormatter.date(from: (dictdirection.value(forKey: "end_time") as? String)!)
        
        timeFormatter.dateFormat = "hh:mm a"
        
        timeFormatter.timeZone = NSTimeZone.local
        
        lblTime.text = "\(timeFormatter.string(from: shift_start_time!)) - \(timeFormatter.string(from: shift_end_time!))"
    }
    
    //MARK:Convert String To Time
    
    func convertTime(para:String) -> String {
       
        print(para)
        let inFormatter = DateFormatter()
        inFormatter.locale = NSLocale(localeIdentifier: "en_US_POSIX") as Locale!
        inFormatter.dateFormat = "HH:mm:ss"
        
        let outFormatter = DateFormatter()
        outFormatter.locale = NSLocale(localeIdentifier: "en_US_POSIX") as Locale!
        outFormatter.dateFormat = "hh:mm a"
        
        let date = inFormatter.date(from: para)! as NSDate
        let outStr = outFormatter.string(from: date as Date) as String
        print(outStr) // -> outputs 04:50
        
        return outStr
    }
    
    //MARK:SetUpFont
    func  setUPFont()
    {
        if(Constant.isiPhone_6_Plus)
        {
            lblTitle.font =  UIFont(name: lblTitle.font.fontName, size: 20.0)
            lblName.font =   UIFont(name: lblName.font.fontName, size: 17.0)
            lblTime.font =   UIFont(name: lblTime.font.fontName, size: 15.0)
            lbladdress.font = UIFont(name: lbladdress.font.fontName, size: 15.0)
            lblZipe.font = UIFont(name: lblZipe.font.fontName, size: 15.0)
            lblKm.font = UIFont(name: lblKm.font.fontName, size: 15.0)
        }
        if(Constant.isiPhone_6)
        {
            lblTitle.font =  UIFont(name: lblTitle.font.fontName, size: 18.0)
            lblName.font =   UIFont(name: lblName.font.fontName, size: 16.0)
            lblTime.font =   UIFont(name: lblTime.font.fontName, size: 14.0)
            lbladdress.font = UIFont(name: lbladdress.font.fontName, size: 14.0)
            lblZipe.font = UIFont(name: lblZipe.font.fontName, size: 14.0)
            lblKm.font = UIFont(name: lblKm.font.fontName, size: 14.0)
        }
        if(Constant.isiPhone_5)
        {
            lblTitle.font =  UIFont(name: lblTitle.font.fontName, size: 15.0)
            lblName.font =   UIFont(name: lblName.font.fontName, size: 13.0)
            lblTime.font =   UIFont(name: lblTime.font.fontName, size: 12.0)
            lbladdress.font = UIFont(name: lbladdress.font.fontName, size: 12.0)
            lblZipe.font = UIFont(name: lblZipe.font.fontName, size: 12.0)
            lblKm.font = UIFont(name: lblKm.font.fontName, size: 13.0)
        }
    }
    
    func setupMapView(){
        
        let strLatitude = dictdirection.value(forKey: "latitude") as! String
        let strLongitude = dictdirection.value(forKey: "longitude") as! String
                    
        doubleLat = (strLatitude as NSString).doubleValue
        doubleLong = (strLongitude as NSString).doubleValue
        
        print(doubleLat)
        print(doubleLong)
        
        print(kGMSMaxZoomLevel)

        let camera = GMSCameraPosition.camera(withLatitude: doubleLat,
                                                          longitude: doubleLong, zoom:kGMSMaxZoomLevel-6) //16
        
        print(camera.target.latitude)
        print(camera.target.longitude)
        
        mapView!.camera = camera
        mapView!.isMyLocationEnabled = true
        mapView!.isIndoorEnabled = false
        
        mapView!.settings.rotateGestures = false;
        mapView!.padding.bottom = 50
        
        marker.title = ""
        marker.snippet = ""
        marker.isDraggable = true
        
        self.marker.icon = UIImage(named: "ClientMarker")
        self.marker.map = self.mapView
    
        
        //Timer For Continuously Change Caregiver Location
        timer = nil
        
        caregiverLongitude = 0.0
        caregiverLatitude = 0.0

        self.CaregiverLocationDisplay()

        DispatchQueue.main.async {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.CaregiverLocationDisplay), userInfo: nil, repeats: true)
        }
        
        timer?.fire()
        print("udp timer on")
  }

    
    
  
    
    //MARK:Distance Between 2 Location
    func distanceBetweenTwoLocations(source:CLLocation,destination:CLLocation) -> Double{
       
        print(source)
        print(destination)
        
        let distanceMeters = source.distance(from: destination)
        let distanceKM = distanceMeters / 1000
        
        print(distanceMeters)
        print(distanceKM)
        
        let strroundTwodigit = String(format:"%.01f", distanceKM)
        let roundedTwoDigit  = (strroundTwodigit as NSString).doubleValue
        return roundedTwoDigit
    }
    //MARK:Click On Direction
    @IBAction func clickOnDirection()
    {
        if SharedInstance.isReachable == true
        {
            if (UIApplication.shared.canOpenURL(NSURL(string:"comgooglemaps://")! as URL)) {
                UIApplication.shared.openURL(NSURL(string:
                
                    "comgooglemaps://?saddr=\(SharedInstance.curLatitude),\(SharedInstance.curLongitude)&daddr=\(doubleLat),\(doubleLong)")! as URL)
            } else {
                UIApplication.shared.openURL(NSURL(string:
                    "http://maps.google.com/maps?saddr=\(SharedInstance.curLatitude),\(SharedInstance.curLongitude)&daddr=\(doubleLat),\(doubleLong)")! as URL)
            }
        }
    }
    
    //MARK:Back
    @IBAction func clickOnBack()
    {
         _ = self.navigationController?.popViewController(animated: true)
        timer?.invalidate()
        timer = nil
    }
    
}

